import React from "react";

const WOList = () => {
  return <div className="flex w-full bg-yellow-500 p-3 flex-1">WOList</div>;
};

export default WOList;
