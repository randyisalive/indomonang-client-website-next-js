export const base_url = "https://erpimj.com/api/api.php";
