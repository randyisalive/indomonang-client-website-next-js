import React from "react";

const Footer = () => {
  return (
    <footer className="flex flex-col justify-end p-2  mt-7 flex-1 ">
      <span className=" w-full bg-red-50">Footer</span>
    </footer>
  );
};

export default Footer;
